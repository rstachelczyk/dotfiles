#!/bin/sh
# Hurtado
printf "\033]4;0;#575757;1;#ff1b00;2;#a5e055;3;#fbe74a;4;#496487;5;#fd5ff1;6;#86e9fe;7;#cbcccb;8;#262626;9;#d51d00;10;#a5df55;11;#fbe84a;12;#89beff;13;#c001c1;14;#86eafe;15;#dbdbdb\007"
printf "\033]10;#dbdbdb;#000000;#bbbbbb\007"
printf "\033]17;#b5d5ff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
