#!/bin/sh
# MaterialDesignColors
printf "\033]4;0;#435b67;1;#fc3841;2;#5cf19e;3;#fed032;4;#37b6ff;5;#fc226e;6;#59ffd1;7;#ffffff;8;#a1b0b8;9;#fc746d;10;#adf7be;11;#fee16c;12;#70cfff;13;#fc669b;14;#9affe6;15;#ffffff\007"
printf "\033]10;#e7ebed;#1d262a;#eaeaea\007"
printf "\033]17;#4e6a78\007"
printf "\033]19;#e7ebed\007"
printf "\033]5;0;#eaeaea\007"
