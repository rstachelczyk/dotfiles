#!/bin/sh
# Apple System Colors
printf "\033]4;0;#1a1a1a;1;#cc372e;2;#26a439;3;#cdac08;4;#0869cb;5;#9647bf;6;#479ec2;7;#98989d;8;#464646;9;#ff453a;10;#32d74b;11;#ffd60a;12;#0a84ff;13;#bf5af2;14;#76d6ff;15;#ffffff\007"
printf "\033]10;#ffffff;#1e1e1e;#98989d\007"
printf "\033]17;#3f638b\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
