#!/bin/sh
# NvimDark
printf "\033]4;0;#07080d;1;#ffc0b9;2;#b3f6c0;3;#fce094;4;#a6dbff;5;#ffcaff;6;#8cf8f7;7;#eef1f8;8;#4f5258;9;#ffc0b9;10;#b3f6c0;11;#fce094;12;#a6dbff;13;#ffcaff;14;#8cf8f7;15;#eef1f8\007"
printf "\033]10;#e0e2ea;#14161b;#9b9ea4\007"
printf "\033]17;#4f5258\007"
printf "\033]19;#e0e2ea\007"
printf "\033]5;0;#e0e2ea\007"
