#!/bin/sh
# CGA
printf "\033]4;0;#000000;1;#aa0000;2;#00aa00;3;#aa5500;4;#0000aa;5;#aa00aa;6;#00aaaa;7;#aaaaaa;8;#555555;9;#ff5555;10;#55ff55;11;#ffff55;12;#5555ff;13;#ff55ff;14;#55ffff;15;#ffffff\007"
printf "\033]10;#aaaaaa;#000000;#b8b8b8\007"
printf "\033]17;#c1deff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
