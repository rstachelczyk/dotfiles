#!/bin/sh
# GruvboxDarkHard
printf "\033]4;0;#1b1b1b;1;#cc241d;2;#98971a;3;#d79921;4;#458588;5;#b16286;6;#689d6a;7;#a89984;8;#928374;9;#fb4934;10;#b8bb26;11;#fabd2f;12;#83a598;13;#d3869b;14;#8ec07c;15;#ebdbb2\007"
printf "\033]10;#ebdbb2;#1b1b1b;#ebdbb2\007"
printf "\033]17;#665c54\007"
printf "\033]19;#ebdbb2\007"
printf "\033]5;0;#ebdbb2\007"
