#!/bin/sh
# Everblush
printf "\033]4;0;#232a2d;1;#e57474;2;#8ccf7e;3;#e5c76b;4;#67b0e8;5;#c47fd5;6;#6cbfbf;7;#b3b9b8;8;#2d3437;9;#ef7e7e;10;#96d988;11;#f4d67a;12;#71baf2;13;#ce89df;14;#67cbe7;15;#bdc3c2\007"
printf "\033]10;#dadada;#141b1e;#dadada\007"
printf "\033]17;#141b1e\007"
printf "\033]19;#dadada\007"
printf "\033]5;0;#dadada\007"
