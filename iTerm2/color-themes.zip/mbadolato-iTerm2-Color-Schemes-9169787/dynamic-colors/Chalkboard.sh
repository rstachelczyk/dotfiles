#!/bin/sh
# Chalkboard
printf "\033]4;0;#000000;1;#c37372;2;#72c373;3;#c2c372;4;#7372c3;5;#c372c2;6;#72c2c3;7;#d9d9d9;8;#323232;9;#dbaaaa;10;#aadbaa;11;#dadbaa;12;#aaaadb;13;#dbaada;14;#aadadb;15;#ffffff\007"
printf "\033]10;#d9e6f2;#29262f;#d9e6f2\007"
printf "\033]17;#073642\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#d96f5f\007"
