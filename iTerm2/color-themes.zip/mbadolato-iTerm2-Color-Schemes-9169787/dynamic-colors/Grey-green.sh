#!/bin/sh
# Grey-green
printf "\033]4;0;#000000;1;#fe1414;2;#74ff00;3;#f1ff01;4;#00deff;5;#ff00f0;6;#00ffbc;7;#ffffff;8;#666666;9;#ff3939;10;#00ff44;11;#ffd100;12;#00afff;13;#ff008a;14;#00ffd3;15;#f5ecec\007"
printf "\033]10;#ffffff;#002a1a;#fff400\007"
printf "\033]17;#517e50\007"
printf "\033]19;#e2e2e2\007"
printf "\033]5;0;#e1e4e3\007"
