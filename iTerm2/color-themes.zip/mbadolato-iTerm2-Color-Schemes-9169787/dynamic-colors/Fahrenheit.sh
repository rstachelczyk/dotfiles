#!/bin/sh
# Fahrenheit
printf "\033]4;0;#1d1d1d;1;#cda074;2;#9e744d;3;#fecf75;4;#720102;5;#734c4d;6;#979797;7;#ffffce;8;#000000;9;#fecea0;10;#cc734d;11;#fd9f4d;12;#cb4a05;13;#4e739f;14;#fed04d;15;#ffffff\007"
printf "\033]10;#ffffce;#000000;#bbbbbb\007"
printf "\033]17;#4e739f\007"
printf "\033]19;#ffffce\007"
printf "\033]5;0;#ffffff\007"
