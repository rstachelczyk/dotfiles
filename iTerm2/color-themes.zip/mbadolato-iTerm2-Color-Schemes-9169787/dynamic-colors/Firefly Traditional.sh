#!/bin/sh
# Firefly Traditional
printf "\033]4;0;#000000;1;#c23720;2;#33bc26;3;#afad24;4;#5a63ff;5;#d53ad2;6;#33bbc7;7;#cccccc;8;#828282;9;#ff3b1e;10;#2ee720;11;#ecec16;12;#838dff;13;#ff5cfe;14;#29f0f0;15;#ebebeb\007"
printf "\033]10;#f5f5f5;#000000;#00f900\007"
printf "\033]17;#cfeac6\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
