#!/bin/sh
# Dark+
printf "\033]4;0;#000000;1;#cd3131;2;#0dbc79;3;#e5e510;4;#2472c8;5;#bc3fbc;6;#11a8cd;7;#e5e5e5;8;#666666;9;#f14c4c;10;#23d18b;11;#f5f543;12;#3b8eea;13;#d670d6;14;#29b8db;15;#e5e5e5\007"
printf "\033]10;#cccccc;#1e1e1e;#ffffff\007"
printf "\033]17;#3a3d41\007"
printf "\033]19;#e0e0e0\007"
printf "\033]5;0;#ffffff\007"
