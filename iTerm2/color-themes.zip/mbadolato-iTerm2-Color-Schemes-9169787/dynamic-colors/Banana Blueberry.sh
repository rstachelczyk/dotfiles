#!/bin/sh
# Banana Blueberry
printf "\033]4;0;#17141f;1;#ff6b7f;2;#00bd9c;3;#e6c62f;4;#22e8df;5;#dc396a;6;#56b6c2;7;#f1f1f1;8;#495162;9;#fe9ea1;10;#98c379;11;#f9e46b;12;#91fff4;13;#da70d6;14;#bcf3ff;15;#ffffff\007"
printf "\033]10;#cccccc;#191323;#e07d13\007"
printf "\033]17;#220525\007"
printf "\033]19;#f4f4f4\007"
printf "\033]5;0;#00bbc3\007"
