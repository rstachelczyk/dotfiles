#!/bin/sh
# HaX0R_BLUE
printf "\033]4;0;#010921;1;#10b6ff;2;#10b6ff;3;#10b6ff;4;#10b6ff;5;#10b6ff;6;#10b6ff;7;#fafafa;8;#080117;9;#00b3f7;10;#00b3f7;11;#00b3f7;12;#00b3f7;13;#00b3f7;14;#00b3f7;15;#fefefe\007"
printf "\033]10;#11b7ff;#010515;#10b6ff\007"
printf "\033]17;#c1e4ff\007"
printf "\033]19;#f6f6f6\007"
printf "\033]5;0;#00b4f8\007"
