#!/bin/sh
# IR_Black
printf "\033]4;0;#4f4f4f;1;#fa6c60;2;#a8ff60;3;#fffeb7;4;#96cafe;5;#fa73fd;6;#c6c5fe;7;#efedef;8;#7b7b7b;9;#fcb6b0;10;#cfffab;11;#ffffcc;12;#b5dcff;13;#fb9cfe;14;#e0e0fe;15;#ffffff\007"
printf "\033]10;#f1f1f1;#000000;#808080\007"
printf "\033]17;#b5d5ff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
