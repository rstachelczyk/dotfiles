#!/bin/sh
# Apple Classic
printf "\033]4;0;#000000;1;#c91b00;2;#00c200;3;#c7c400;4;#0225c7;5;#ca30c7;6;#00c5c7;7;#c7c7c7;8;#686868;9;#ff6e67;10;#5ffa68;11;#fffc67;12;#6871ff;13;#ff77ff;14;#60fdff;15;#ffffff\007"
printf "\033]10;#d5a200;#2c2b2b;#c7c7c7\007"
printf "\033]17;#6b5b02\007"
printf "\033]19;#67e000\007"
printf "\033]5;0;#ffffff\007"
