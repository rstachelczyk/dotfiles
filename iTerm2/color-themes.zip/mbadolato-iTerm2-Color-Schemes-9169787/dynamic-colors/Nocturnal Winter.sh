#!/bin/sh
# Nocturnal Winter
printf "\033]4;0;#4d4d4d;1;#f12d52;2;#09cd7e;3;#f5f17a;4;#3182e0;5;#ff2b6d;6;#09c87a;7;#fcfcfc;8;#808080;9;#f16d86;10;#0ae78d;11;#fffc67;12;#6096ff;13;#ff78a2;14;#0ae78d;15;#ffffff\007"
printf "\033]10;#e6e5e5;#0d0d17;#e6e5e5\007"
printf "\033]17;#adbdd0\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#e8e8e8\007"
