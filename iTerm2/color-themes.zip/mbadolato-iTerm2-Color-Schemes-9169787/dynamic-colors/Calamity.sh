#!/bin/sh
# Calamity
printf "\033]4;0;#2f2833;1;#fc644d;2;#a5f69c;3;#e9d7a5;4;#3b79c7;5;#f92672;6;#74d3de;7;#d5ced9;8;#7e6c88;9;#fc644d;10;#a5f69c;11;#e9d7a5;12;#3b79c7;13;#f92672;14;#74d3de;15;#ffffff\007"
printf "\033]10;#d5ced9;#2f2833;#d5ced9\007"
printf "\033]17;#7e6c88\007"
printf "\033]19;#d5ced9\007"
printf "\033]5;0;#d5ced9\007"
