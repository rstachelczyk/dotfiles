#!/bin/sh
# Japanesque
printf "\033]4;0;#343935;1;#cf3f61;2;#7bb75b;3;#e9b32a;4;#4c9ad4;5;#a57fc4;6;#389aad;7;#fafaf6;8;#595b59;9;#d18fa6;10;#767f2c;11;#78592f;12;#135979;13;#604291;14;#76bbca;15;#b2b5ae\007"
printf "\033]10;#f7f6ec;#1e1e1e;#edcf4f\007"
printf "\033]17;#175877\007"
printf "\033]19;#f7f6ec\007"
printf "\033]5;0;#fffffa\007"
