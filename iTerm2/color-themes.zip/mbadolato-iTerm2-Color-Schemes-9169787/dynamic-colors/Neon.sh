#!/bin/sh
# Neon
printf "\033]4;0;#000000;1;#ff3045;2;#5ffa74;3;#fffc7e;4;#0208cb;5;#f924e7;6;#00fffc;7;#c7c7c7;8;#686868;9;#ff5a5a;10;#75ff88;11;#fffd96;12;#3c40cb;13;#f15be5;14;#88fffe;15;#ffffff\007"
printf "\033]10;#00fffc;#14161a;#c7c7c7\007"
printf "\033]17;#0013ff\007"
printf "\033]19;#08d2cf\007"
printf "\033]5;0;#ff3099\007"
