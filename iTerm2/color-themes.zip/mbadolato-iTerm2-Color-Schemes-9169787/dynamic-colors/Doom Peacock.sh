#!/bin/sh
# Doom Peacock
printf "\033]4;0;#1c1f24;1;#cb4b16;2;#26a6a6;3;#bcd42a;4;#2a6cc6;5;#a9a1e1;6;#5699af;7;#ede0ce;8;#2b2a27;9;#ff5d38;10;#98be65;11;#e6f972;12;#51afef;13;#c678dd;14;#46d9ff;15;#dfdfdf\007"
printf "\033]10;#ede0ce;#2b2a27;#9c9c9d\007"
printf "\033]17;#a60033\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ede0ce\007"
