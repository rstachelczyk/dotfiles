#!/bin/sh
# Adventure
printf "\033]4;0;#040404;1;#d84a33;2;#5da602;3;#eebb6e;4;#417ab3;5;#e5c499;6;#bdcfe5;7;#dbded8;8;#685656;9;#d76b42;10;#99b52c;11;#ffb670;12;#97d7ef;13;#aa7900;14;#bdcfe5;15;#e4d5c7\007"
printf "\033]10;#feffff;#040404;#feffff\007"
printf "\033]17;#606060\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
