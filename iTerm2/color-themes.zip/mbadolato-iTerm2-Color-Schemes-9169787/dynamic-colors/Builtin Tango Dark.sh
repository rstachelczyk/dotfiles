#!/bin/sh
# Builtin Tango Dark
printf "\033]4;0;#000000;1;#cc0000;2;#4e9a06;3;#c4a000;4;#3465a4;5;#75507b;6;#06989a;7;#d3d7cf;8;#555753;9;#ef2929;10;#8ae234;11;#fce94f;12;#729fcf;13;#ad7fa8;14;#34e2e2;15;#eeeeec\007"
printf "\033]10;#ffffff;#000000;#ffffff\007"
printf "\033]17;#b5d5ff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
