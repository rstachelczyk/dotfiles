#!/bin/sh
# DotGov
printf "\033]4;0;#191919;1;#bf091d;2;#3d9751;3;#f6bb34;4;#17b2e0;5;#7830b0;6;#8bd2ed;7;#ffffff;8;#191919;9;#bf091d;10;#3d9751;11;#f6bb34;12;#17b2e0;13;#7830b0;14;#8bd2ed;15;#ffffff\007"
printf "\033]10;#ebebeb;#262c35;#d9002f\007"
printf "\033]17;#1a4080\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#fbab19\007"
