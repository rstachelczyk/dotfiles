#!/bin/sh
# Aardvark Blue
printf "\033]4;0;#191919;1;#aa342e;2;#4b8c0f;3;#dbba00;4;#1370d3;5;#c43ac3;6;#008eb0;7;#bebebe;8;#454545;9;#f05b50;10;#95dc55;11;#ffe763;12;#60a4ec;13;#e26be2;14;#60b6cb;15;#f7f7f7\007"
printf "\033]10;#dddddd;#102040;#007acc\007"
printf "\033]17;#bfdbfe\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#f7f7f7\007"
